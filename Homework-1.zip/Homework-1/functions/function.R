
Rss <- function(y, yhat){
  error <- y - yhat
  out <- sum(error^2)
  return(out)
}


Tss <- function(y){
  ybar <- mean(y)
  out <- sum((y-ybar)^2)
  return(out)
}


Rse <- function(y,yhat){
  rss <- sum((y - yhat)^2)
  n <- length(y)
  out <- sqrt(rss / (n-2))
  return(out)
}



Mse <- function(y,yhat){
  out <- mean((y-yhat)^2)
  return(out)
}




